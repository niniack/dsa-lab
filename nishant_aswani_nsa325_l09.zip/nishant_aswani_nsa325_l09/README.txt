**PLEASE BUILD THE FILE**

Notes:
--  main.cpp is a driver function to demonstrate functionality
--  binarySearchTree.hpp and binarySearchTree.cpp carry the implementation


Build Instructions:
1. Change to the directory with the source code

2. Run the following command:
--  make

The output will be an object file (.o) and a text file (.txt). The .txt file
holds the print outs from the main function.

3. Run the following command for clean-up:
-- make clean
